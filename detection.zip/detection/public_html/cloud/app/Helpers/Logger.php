<?php

namespace App\Helpers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Helpers\PersianCalendar;
use App\Helpers\Telegram;

class Logger 
{
    public static Function log($title ='log', Request $request, $options =[]){
        $options = array_merge([
                "db" => true,
                "send" => true,
                "detail" => true,
            ], $options);
            
            $input = $request->all();
              
            $detail = [];  
            if($options['detail']){
              
                $detail['ip'] = $request->ip();  
                $detail['ipDetail'] = Logger::getIpDetail($detail['ip']);  
                
                $detail['userAgent'] =  $request->header('user-agent');  
                $detail['cookie'] =  $request->cookie();  
                 
            }
            
            $detail= Logger::getJson($detail);
            $input= Logger::getJson($input);
            
            if($options['db']){
                  DB::insert('insert into logs (title,content,detail, date) values (?, ?, ?, ?)',
        [$title, $input, $detail, PersianCalendar::now()]);   
            }
            
               if($options['send']){
                     Telegram::send(['message'=> $title.chr(10).$input.chr(10).$detail]);  
                
                Discord::send(['content'=> "$title ```json\n $input \n $detail```"]);  
                     
            }
       
            
            
    }
    
    public static Function getJson($array){
        return json_encode($array, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT |JSON_UNESCAPED_LINE_TERMINATORS | JSON_PARTIAL_OUTPUT_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }
    
     public static Function getIpDetail($ip){
         return json_decode(file_get_contents("http://ip-api.com/json/$ip?fields=529"), true);
     }
    
}