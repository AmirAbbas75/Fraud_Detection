<?php

namespace App\Http\Controllers;

use App\Helpers\Post;
use Illuminate\Routing\ResponseFactory;
use Illuminate\Http\Request;


use Illuminate\Support\Facades\Artisan;
use PHPUnit\Framework\ExpectationFailedException;
use Symfony\Component\HttpKernel\Exception\HttpException;


class DetectionController extends Controller
{

    public function detect(Request $request)
    {

 	return response()->json(['status' => 'done']);
    }


}
