
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title> Detection Micro Service </title>
    <meta name="description" content="Selamat datang di eLection, pemilihan kandidat berbasis online yang dikembangkan oleh Tripath Projects">
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <link rel="shortcut icon" href="./favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/shards.min.css">
    <link rel="stylesheet" href="css/shards.tripath.css?v=1.1.0">
</head>

<body style="height: 100vh; padding: 32px; text-align: center">
	
		<h1> Detection Micro Service Working... </h1>
</body>
</html>

